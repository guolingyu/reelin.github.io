(function($) {

    var key = 'js-dev-key';
    var uuid ;
    var group_id = '13';

//    var auth = $('#auth').val();
    var key = $('#auth').val()['api-key'];
    var invitationCode = $('#invitation').val();

    var qiniu = {};

    var h_stand = 300;
    var w_stand = 400;
    var w_win = 600;
    var w2 = 0;

    var page = 1;
    var hasNext = false;

//    $.ajaxSetup({
//        headers: {'Authorization': 'Basic '+ $.base64_encode(auth.uuid + ':' + auth.key)}
//    });



    /**
     * 此段代码为测试用例
     * 若客户端可以判断用户已经登陆可以直接调用post之后的回调
     * 若不能要在页面中加入用户信息
     */
    $.ajaxSetup({
        headers: {'Authorization': 'Basic '+ $.base64_encode('anonymous:'+key)}
    });
    $.post('/api/v1/auth/email/login/',{'email': '117361827@qq.com', 'password': 'rl110110'}, function(data){
        if (data.user) {
            uuid = data.user.uuid;
            $.ajaxSetup({
                headers: {'Authorization': 'Basic '+ $.base64_encode(data.user.uuid+':'+key)}
            });
            main();
        }
    });

    function main() {
        var wrapper = $('.tp-wrapper');
        var footer = $('footer');
        var invi_wrapper = $('.tp-invitation');
        var btn_invitation = invi_wrapper.find('a');
        var win_height = $(window).height();

        if (invitationCode) {
            wrapper.height(win_height).css('overflow', 'hidden');
            footer.hide();
            invi_wrapper.height(win_height - 340);
            btn_invitation.css({
                'margin-top': (win_height - 440)/2
            });
            $('.tp-btn-blue').on('click', function(e) {
                e.preventDefault();
                invitation();
            });
        } else {
            group();
        }
    }


    /**
     * 邀请页面对应的操作
     */
    function invitation() {
        var url = '/api/v1/users/self/groups/';
        $.post(url, {'invitation': invitationCode}, function(data) {
            if (data && data) {
                $('footer').show();
                $('.tp-wrapper').height('auto').attr('style', '');
                $('.tp-invitation').hide();
                group();
            }
        });
    }

    /**
     * 相册页面对应的操作
     */
    function group() {
        getAlbumInfo();
        uploadImage();
        getGroupImages(page);
    }


    /**
     * 获取当前相册信息
     */
    function getAlbumInfo() {
        var url = '/api/v1/groups/'+ group_id +'/posts/users/';
        $.get(url, function(data){
            if (data.group && data.group.id) {
                var album_user = data.users;
                addUsers(album_user);
                $('.js-album-name').html('「' + data.group.name + '」');
            }
        });
    }

    /**
     * 获取群友
     * @param users
     */
    function addUsers(users) {
        var template = $('<div class="tp-member-item">\
            <img src="" alt="" />\
            <p class="tp-member-nick"></p>\
            </div>');
        var len = users.length;
        for (var i = 0; i < len; i++) {
            template.find('img').attr({
                'src': users[i].headimgurl,
                'alt': users[i].nickname
            });
            template.find('.tp-member-nick').html(users[i].nickname);
            $('.tp-member-thumb').append(template);
        }

    }

    /**
     * 获取七牛token等信息，初始上传信息
     */
    function uploadImage() {
        $.get('/api/v1/apps/qiniu/', function(data){
            if (data) {
                qiniu = data;
                var uploader = Qiniu.uploader({
                    runtimes: 'html5,flash,html4',    //上传模式,依次退化
                    browse_button: 'js-upload-image',       //上传选择的点选按钮，**必需**
                    uptoken_url: qiniu['token'],            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                    container: 'container',
                    // downtoken_url: '/downtoken',
                    // Ajax请求downToken的Url，私有空间时使用,JS-SDK将向该地址POST文件的key和domain,服务端返回的JSON必须包含`url`字段，`url`值为该文件的下载地址
                    uptoken : qiniu['token'], //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                    unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK会为每个文件自动生成key（文件名）
                    save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK在前端将不对key进行任何处理
                    domain: qiniu['https_domain'],   //bucket 域名，下载资源时用到，**必需**
                    get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
                    container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
                    max_file_size: '1000mb',           //最大文件体积限制
                    flash_swf_url: 'js/plupload/Moxie.swf',  //引入flash,相对路径
                    max_retries: 3,                   //上传失败最大重试次数
                    dragdrop: false,                   //开启可拖曳上传
                    drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                    chunk_size: '4mb',                //分块上传时，每片的体积
                    auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传,
                    multi_selection: false,
                    init: {
                        'FilesAdded': function(up, files) {
                            plupload.each(files, function(file) {
                                // 文件添加进队列后,处理相关的事情
                                var progress = new FileProgress(file, 'fsUploadProgress');
                                progress.bindUploadCancel(up);
                                progress.setStatus("正在上传照片");
                            });
                        },
                        'BeforeUpload': function(up, file) {
                            // 每个文件上传前,处理相关的事情
                            window.isloading = false;
                            file.name = file.name;
                        },
                        'UploadProgress': function(up, file) {
                            // 每个文件上传时,处理相关的事情
                            var progress = new FileProgress(file, 'fsUploadProgress');
                            var chunk_size = plupload.parseSize(this.getOption('chunk_size'));

                            if (!window.isloading) {
                                window.isloading = true;
                                progress.setImage(up, file.name);
                            }
                            progress.setProgress(file.percent + "%", file.speed, chunk_size);
                        },
                        'FileUploaded': function(up, file, info) {
                            // 每个文件上传之后，处理相关的事情

                            window.isloading = false;
                            var domain = up.getOption('domain'),
                                res = $.parseJSON(info),
                                sourceLink = domain + res.key;

//                                progress.setComplete(up, info);

//                            $.ajaxSetup({
//                                headers: {
//                                    'Content-Type': 'application/x-www-form-urlencoded',
//                                    'Authorization': 'QBox '+ key
//                                }
//                            });
//                            $.post('http://api.qiniu.com/pfop/',{
//                                'bucket': encodeURI(qiniu['https_domain']),
//                                'key': encodeURI(res.key),
//                                'fops': encodeURI(qiniu['https_domain'])
//
//                            }).done(function(data){});

                            var imageInfo = Qiniu.imageInfo(res.key);
                            $.post('/api/v1/posts/',{
                                'group_id': group_id,
                                'url': sourceLink,
                                'width': imageInfo.width,
                                'height': imageInfo.height,
                                'last': 'true'
                            }, function(data){
                                if (data.post.id) {
                                    $('#tp-album-thumb .tp-photo-wrapper').addClass('delete');
                                    w2 = 0;
                                    getGroupImages(page, file.id);
                                }
                            });
                        },
                        'Error': function(up, err, errTip) {
                            //上传出错时,处理相关的事情
                            var progress = new FileProgress(err.file, 'fsUploadProgress');
                            progress.setError();
                            progress.setStatus(errTip.replace(/。\(.*?\)/g, ''));
                        },
                        'UploadComplete': function() {
                            //队列文件处理完毕后,处理相关的事情
                        },
                        'Key': function(up, file) {
                            // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
                            // 该配置必须要在 unique_names: false , save_key: false 时才生效

                            var key = uuid+'.jpg';
                            // do something with key here
                            return key;
                        }
                    }
                });

            }
        });
    }

    /* 读取相册图片处理 */
    function getGroupImages(page, fileId) {
        var data = {
            'page': page || 1
        };
        $.get('/api/v1/groups/'+ group_id +'/posts/',data, function(data){
            var images_len = data.posts.length,
                $delete = $('#tp-album-thumb .tp-photo-wrapper.delete');
            if (images_len) {
                hasNext = data.pagination.has_next;

                for (var i = 0; i < images_len; i ++) {
                    if (i == 0) {
                        $('#'+fileId).remove();
                    }
                    insertImage(data.posts[i].photo, images_len);
                }
                if ($delete.length) {
                    $delete.remove();
                }
            }
        });
    }


    var temp_height, temp_width;

    /**
     * 根据图片尺寸计算并插入DOM
     * @param image
     * @param len
     */
    function insertImage(image, len) {
        var imgHeight = image.height;
        var imgWidth = image.width;
        var imgUrl = image.url;
        var $imgWrapper = $('<a href="\"' + ' class="js-album-item"></a>');
        var $img = $('<img src="">').attr('src', imgUrl);

        temp_height = h_stand;
        temp_width = h_stand * imgWidth / imgHeight;

        $imgWrapper.append($img.width(temp_width).height(temp_height));

        if (w2 < w_stand) {
            if (w2 == 0) {
                $('#tp-album-thumb').append($('<div class="tp-photo-wrapper clearfix"></div>').append($imgWrapper));
            } else {
                $('.tp-photo-wrapper').last().append($imgWrapper);
            }
            w2 = w2 + temp_width;

        } else {
            handleImage();
            w2 = 0;
            $('#tp-album-thumb').append($('<div class="tp-photo-wrapper clearfix"></div>').append($imgWrapper));
            w2 = w2 + temp_width;

        }
        if ($('.tp-photo-wrapper img').length == len) {
            handleImage();
        }

    }

    /**
     * 调整整行图片
     */
    function handleImage() {
        var $imageWrapper = $('.tp-photo-wrapper').last(),
            images = $imageWrapper.find('img'),
            w_current = w_win + (images.length-1) * 20,
            h_deta = h_stand * w_current / sum(images);

        if (w2 != w_win) {
            /* w2/w_stand = h_stand/deta_h */
            images.each(function() {
                $(this).css({
                    'width': $(this).width() / $(this).height() * h_deta,
                    'height': h_deta
                });
            });
            var w_wrapper = $('.tp-photo-wrapper').last().width(),
                w_deta = Math.abs(w_current - w_wrapper) / images.length;
            if (w_wrapper < w_win) {
                images.each(function() {
                    $(this).width($(this).width() + w_deta);
                });

            } else if (w_wrapper > w_win) {
                images.each(function() {
                    $(this).width($(this).width() - w_deta);
                });
            }
        }
    }
    function sum(images) {
        var sum = 0;
        var len = images.length;
        for (var i = 0; i < len; i++) {
            sum += $(images[i]).width();
        }
        return sum;
    }

    $('.tp-album-tab .tp-album-number').click(function(e) {
        e.preventDefault();
        $('.tp-album-tab .active').removeClass('active');
        $(this).addClass('active');
        $('.tp-album-photo').show();
        $('.tp-member-wrapper').hide();
    });
    $('.tp-album-tab .tp-album-member').click(function(e) {
        e.preventDefault();
        $('.tp-album-tab .active').removeClass('active');
        $(this).addClass('active');
        $('.tp-album-photo').hide();
        $('.tp-member-wrapper').show();
    });
    $('#js-upload-image').on('click', function(e) {
        e.preventDefault();
        $('html,body').scrollTop(590);
    });


    /**
     * 下拉加载
     */
    $(document).scroll(function(){
        if ( $(document).height() - ($(document).scrollTop() + $(window).height()) < 200  ) {
            if (hasNext) {
                $(".loading").show();
                setTimeout(function(){
                    $(".loading").hide();
                    getGroupImages(++page);
                },3000);
            }
        }


    });





})(jQuery);