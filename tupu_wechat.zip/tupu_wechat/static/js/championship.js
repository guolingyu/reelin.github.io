(function($){
    /**
     * 测试用key，postId直接赋值
     * 正式环境用key，postId的取值
     */
    var key = 'js-dev-key';
    var group_id = '12';

//    var key = $('#key').val();
//    var group_id = $('#groupId').val();

    /**
     * 此段代码为测试用例
     * 若客户端可以判断用户已经登陆可以直接调用post之后的回调
     * 若不能要在页面中加入用户信息
     */
    $.ajaxSetup({
        headers: {'Authorization': 'Basic '+ $.base64_encode('anonymous:'+key)}
    });
    $.post('/api/v1/auth/email/login/',{'email': '117361827@qq.com', 'password': 'rl110110'}, function(data){
        if (data.user) {
            $.ajaxSetup({
                headers: {'Authorization': 'Basic '+ $.base64_encode(data.user.uuid+':'+key)}
            });

            getChampionship();
        }
    });


    /**
     *  读取相册图片处理
     **/
    function getChampionship() {

        $.get('/api/v1/groups/'+ group_id +'/championship/', function(data){
            if (data && data.championship) {
                var endTime = new Date(data.championship.end_at).getTime();
                var nowTime = new Date().getTime();
                var user = data.championship.user;
                $('.js-album-name').html('「' + data.championship.group.name + '」');
                if (endTime > nowTime) {
                    countDown(endTime-nowTime);
                    $('.counting').show();
                } else {
                    $('.js-avatar').attr('src', user.headimgurl);
                    $('.js-like-user-nick').html(user.nickname);
                    $('.tp-like-title span').html(user.championships_count);
                    $('.result').show();
                }

            }
        });
    }

    var temp_day, temp_hour, temp_min, temp_second;
    var timer;

    /**
     * 倒计时
     * @param subTime
     */
    function countDown(subTime) {
        timer = setInterval(function() {
            subTime = subTime - 1000;
            setCountDown(subTime);
        }, 1000);
    }
    function setCountDown(subTime) {
        temp_day = Math.floor(subTime/1000/60/60/24);
        temp_hour = Math.floor(subTime%(1000*60*60*24)/1000/60/60);
        temp_min = Math.floor(subTime%(1000*60*60*24)%(1000*60*60)/1000/60);
        temp_second = Math.floor(subTime%(1000*60*60*24)%(1000*60*60)%(1000*60)/1000);

        $('.js-deadline-time .day').html(toTwoDigit(temp_day));
        $('.js-deadline-time .hour').html(toTwoDigit(temp_hour));
        $('.js-deadline-time .min').html(toTwoDigit(temp_min));
        $('.js-deadline-time .second').html(toTwoDigit(temp_second));
    }

    // 把数字转换成两位数的字符串
    function toTwoDigit(num) { return num < 10 ? "0" + num : num; }


})(jQuery);