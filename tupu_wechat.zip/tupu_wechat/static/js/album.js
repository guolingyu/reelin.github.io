(function($) {
    /**
     * 测试用key，postId直接赋值
     * 正式环境用key，postId的取值
     */

    var key = 'js-dev-key';
    var postId = '183';


//    var auth = $('#auth').val();
//    var postId = $('#postId').val();
    var h_stand = 300;
    var w_stand = 400;
    var w_win = 600;
    var w2 = 0;

    var group_id = '13';
    var page = 1;
    var userId;

//    $.ajaxSetup({
//        headers: {'Authorization': 'Basic '+ $.base64_encode(auth.uuid + ':' + auth.key)}
//    });
//    getUserInfo();
//    getAlbumInfo();
//    getAlbum();
//


    /**
     * 此段代码为测试用例
     * 若客户端可以判断用户已经登陆可以直接调用post之后的回调
     * 若不能要在页面中加入用户信息
     */
    $.ajaxSetup({
        headers: {'Authorization': 'Basic '+ $.base64_encode('anonymous:'+key)}
    });
    $.post('/api/v1/auth/email/login/',{'email': '117361827@qq.com', 'password': 'rl110110'}, function(data){
        if (data.user) {
            $.ajaxSetup({
                headers: {'Authorization': 'Basic '+ $.base64_encode(data.user.uuid+':'+key)}
            });
            getUserInfo();
            getAlbumInfo();
            getAlbum();
        }
    });

    /**
     * 获取用户名称和头像
     */
    function getUserInfo() {
        var url = '/api/v1/users/self/';
        $.get(url, function(data){
            if (data.user.id) {
                $('.tp-user-name').html(data.user.nickname);
                $('.js-user-avatar').attr('src', data.user.headimgurl);
                userId = data.user.id;
            }
        });
    }

    /**
     * 获取当前用户在某个相册中发布的照片
     */
    function getAlbum() {
        var url = '/api/v1/groups/'+ group_id +'/posts/';
        var data = {
            'page': page || 1,
            'user_id': userId
        };
        $.get(url, data, function(data){
            var images_len = data.posts.length;
            if (images_len) {
                for (var i = 0; i < images_len; i ++) {
                    insertImage(data.posts[i], images_len);
                }
            }
        });
    }

    /**
     * 获取当前相册信息
     */
    function getAlbumInfo() {
        var url = '/api/v1/groups/'+ group_id +'/posts/users/';
        $.get(url, function(data){
            if (data.group && data.group.id) {
                $('.js-album-name').html('「' + data.group.name + '」');
            }
        });
    }

    var temp_height, temp_width;

    /**
     * 根据图片尺寸计算并插入DOM
     * @param image
     * @param len
     */
    function insertImage(image, len) {
        var imgHeight = image.height;
        var imgWidth = image.width;
        var imgUrl = image.url;
        var $imgWrapper = $('<a href="\"' + ' class="js-album-item"></a>');
        var $img = $('<img src="">').attr('src', imgUrl);

        temp_height = h_stand;
        temp_width = h_stand * imgWidth / imgHeight;

        $imgWrapper.append($img.width(temp_width).height(temp_height));

        if (w2 < w_stand) {
            if (w2 == 0) {
                $('#tp-album-thumb').append($('<div class="tp-photo-wrapper clearfix"></div>').append($imgWrapper));
            } else {
                $('.tp-photo-wrapper').last().append($imgWrapper);
            }
            w2 = w2 + temp_width;

        } else {
            handleImage();
            w2 = 0;
            $('#tp-album-thumb').append($('<div class="tp-photo-wrapper clearfix"></div>').append($imgWrapper));
            w2 = w2 + temp_width;

        }
        if ($('.tp-photo-wrapper img').length == len) {
            handleImage();
        }

    }

    /**
     * 调整整行图片
     */
    function handleImage() {
        var $imageWrapper = $('.tp-photo-wrapper').last(),
            images = $imageWrapper.find('img'),
            w_current = w_win + (images.length-1) * 20,
            h_deta = h_stand * w_current / sum(images);

        if (w2 != w_win) {
            /* w2/w_stand = h_stand/deta_h */
            images.each(function() {
                $(this).css({
                    'width': $(this).width() / $(this).height() * h_deta,
                    'height': h_deta
                });
            });
            var w_wrapper = $('.tp-photo-wrapper').last().width(),
                w_deta = Math.abs(w_current - w_wrapper) / images.length;
            if (w_wrapper < w_win) {
                images.each(function() {
                    $(this).width($(this).width() + w_deta);
                });

            } else if (w_wrapper > w_win) {
                images.each(function() {
                    $(this).width($(this).width() - w_deta);
                });
            }
        }
    }
    function sum(images) {
        var sum = 0;
        var len = images.length;
        for (var i = 0; i < len; i++) {
            sum += $(images[i]).width();
        }
        return sum;
    }

    /**
     * 先判断是横图还是竖图，横图按照浏览器宽，竖图按照浏览器高
     * 如果原始尺寸小于浏览器高度与宽度，直接显示原始尺寸，无须放大。
     */
    function modal(post) {
        var modal = $('.modal');

        var photo = post.photo;
        var url = photo.url;
        var img_width = photo.width;
        var img_height = photo.height;

        var img = $('.modal-main img');

        var win_width = 640,
            win_height = $(window).height();

        var margin_top,
            height_new,
            width_new,
            margin_left;

        $('.modal, .modal-main').height(win_height);
        img.attr('src', url);
        $('.js-like-num').html(post.likes_count);

        if (post.liked) {
            $('.js-tp-like').addClass('tp-liked-black');
        } else {
            $('.js-tp-like').removeClass('tp-liked-black');
        }

        if (img_height > win_height || img_width > win_width) {
            if (img_width >= img_height) {
                var img_newHeight = img_height * 640 / win_height;

                margin_top = (win_height - img_newHeight)/2;
                width_new = win_width;
                height_new = 'auto';
                margin_left = -(img_width - win_width)/2;

            } else {
                margin_top = 0;
                width_new = 'auto';
                height_new = win_height;
                margin_left = 'auto';
            }
        } else {
            margin_top = (win_height - img_height)/2;
            height_new = 'auto';
            width_new = 'auto';
            margin_left = 'auto';
        }
        img.css({
            'margin-top': margin_top,
            'width': height_new,
            'height': width_new,
            'margin-left': margin_left
        });
        modal.show();

    }

    $('.modal-close').on('click', function(e) {
        e.preventDefault();
        $(this).parent().hide();
    });
    $('.tp-wrapper').on('click', '#tp-album-thumb a', function(e) {
        e.preventDefault();
        modal($(this).data());
    });

    /* 点赞 */
    $('.js-tp-like').on('click', function(e) {
        var that = $(this),
            likeNum = $('.js-like-num');

        e.preventDefault();
        if (that.hasClass('tp-liked-black')) {
            that.removeClass('tp-liked-black');
            $('.tp-heart').addClass('broken');
                $('.tp-heart').removeClass('broken');
                likeNum.html(parseInt(likeNum.html())-1);
                addLike();

        } else {
            that.addClass('tp-liked-black');
            likeNum.html(parseInt(likeNum.html())+1);
            addLike();
        }
    });
    function addLike() {
        var url = '/api/v1/posts/' + postId + '/likes/';
        $.post(url);
    }


    $('.tp-close').on('click', function(e){
        e.preventDefault();
        $(this).parent().animate({
            'margin-top': '-95px'
        }, 1000);
    });

})(jQuery);